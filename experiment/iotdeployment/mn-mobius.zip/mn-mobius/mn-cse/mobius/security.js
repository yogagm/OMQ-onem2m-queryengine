/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @copyright KETI Korea 2016, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var url = require('url');
var util = require('util');
var db = require('./db_action');

exports.check = function(request, ty, acpiList, access_value, callback) {
    if(ty == '1') { // check selfPrevileges
        acpiList = [url.parse(request.url).pathname.toLowerCase()];
        var sql = util.format("select * from acp where ri = \'%s\'", acpiList[0]);
        db.getResult(sql, '', function (err, results_acp) {
            if (!err) {
                for (var i = 0; i < results_acp.length; i++) {
                    var pvsObj = JSON.parse(results_acp[i].pvs);
                    var from = request.headers['x-m2m-origin'];
                    for(var index in pvsObj.acr) {
                        if(pvsObj.acr.hasOwnProperty(index)) {
                            try {
                                var re = new RegExp(from + '\\b');
                                for (var acor_idx in pvsObj.acr[index].acor) {
                                    if (pvsObj.acr[index].acor.hasOwnProperty(acor_idx)) {
                                        if (pvsObj.acr[index].acor[acor_idx].match(re) || pvsObj.acr[index].acor[acor_idx].toLowerCase() == 'all') {
                                            if ((pvsObj.acr[index].acop & access_value) == access_value) {
                                                callback('1');
                                                return '1';
                                            }
                                        }
                                    }
                                }
                            }
                            catch (e) {

                            }
                        }
                    }
                }
                callback('0');
                return '0';
            }
            else {
                console.log('query error: ' + results_acp.message);
                callback('0');
                return '0';
            }
        });
    }
    else {
        if (acpiList.length == 0) {
            // we decide to permit to everybody in this case which is not set accessControlPolicy
            // this policy may change to not permit later
            callback('1');
            return '1';
        }

        sql = util.format("select * from acp where ri in (" + JSON.stringify(acpiList).replace('[', '').replace(']', '') + ")");
        db.getResult(sql, '', function (err, results_acp) {
            if (!err) {
                for (var i = 0; i < results_acp.length; i++) {
                    var pvObj = JSON.parse(results_acp[i].pv);
                    var from = request.headers['x-m2m-origin'];
                    for(var index in pvObj.acr) {
                        if(pvObj.acr.hasOwnProperty(index)) {
                            try {
                                var re = new RegExp(from + '\\b');
                                for (var acor_idx in pvObj.acr[index].acor) {
                                    if(pvObj.acr[index].acor.hasOwnProperty(acor_idx)) {
                                        if (pvObj.acr[index].acor[acor_idx].match(re) || pvObj.acr[index].acor[acor_idx] == 'all') {
                                            if ((pvObj.acr[index].acop & access_value) == access_value) {
                                                callback('1');
                                                return '1';
                                            }
                                        }
                                    }
                                }
                            }
                            catch (e) {

                            }
                        }
                    }
                }
                callback('0');
                return '0';
            }
            else {
                console.log('query error: ' + results_acp.message);
                callback('0');
                return '0';
            }
        });
    }
};
