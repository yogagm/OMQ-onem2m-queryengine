const unirest = require('unirest');
const async = require('async');

const createHeaders = function(sending=false, resource_type = 0, originator) {
    if(sending == true) {
        return {"X-M2M-Origin": originator,
                "X-M2M-RI": global.config.cse.ri,
                "Accept": "application/json",
                "Content-Type": "application/json;ty=" + resource_type.toString()
        };
    } else {
        return {"X-M2M-Origin": originator,
                "X-M2M-RI": global.config.cse.ri,
                "Accept": "application/json"
        };
    }
};


const singleCSERequest = function(req, callback) {
    if(!("body" in req )) {
        req["body"] = "";
    }

    if(!("query" in req)){
        req["query"] = {}
    }

    if(global.config.cse.mobius == true) {
        // Only use first level of base
        // This case applied in MOBIUS CSE
        req["base"] = "/" + req["base"].split("/")[1]
    }

    if(req["viaRi"] == true){
        addr = req["address"] + req["point"];
    } else {
        addr = req["address"] + req["base"] + req["point"];

    }

    // Remove the last "/" in addr if exist
    if(addr[addr.length - 1] == "/") {
        addr = addr.slice(0, addr.length-1);
    }
    //global.winston.info("oneM2M CSE", {method: req["method"], addr: addr, header: createHeaders(true, req["ty"], req["originator"])});
    unirest(req["method"], addr).query(req["query"]).headers(createHeaders(true, req["ty"], req["originator"]))
            .send(req["body"]).end(function(response) {
        if(response.code == 200 || response.code == 201) {
            callback(null, response.body)
        } else {
            if (req.convertToPut == true && req.method == "POST") {
                if(req["point"] != "/") {
                    req["point"] += "/" + req["body"][Object.keys(req["body"])[0]]["rn"];
                } else {
                    req["point"] += req["body"][Object.keys(req["body"])[0]]["rn"];
                }
                delete req["body"][Object.keys(req["body"])[0]]["rn"];
                for(key in req["npAttr"]) {
                    delete req["body"][Object.keys(req["body"])[0]][req["npAttr"][key]];
                }
                req["method"] = "PUT";
                req["convertToPut"] = false;
                singleCSERequest(req, function(err, results) {
                    callback(err, results);
                });

            } else {
                callback(Error(response.code), response.body);
            }
        }
    });
};

exports.request = singleCSERequest;

const serialCSERequests = function(reqs, callback) {
    async.eachSeries(reqs, function(req, callback) {
        singleCSERequest(req, function(err, results) {
            callback(err, results);
        });
    }, function(err, results) {
        callback(err, results);
    });
}

exports.serialRequests = serialCSERequests;
