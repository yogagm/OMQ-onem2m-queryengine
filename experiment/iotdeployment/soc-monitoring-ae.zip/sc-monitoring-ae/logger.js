var winston = require('winston');
exports.createLogger = function(header) {
    return new (winston.Logger)({
      transports: [
        new (winston.transports.Console)({
          //level: 'error',
          timestamp: function() {
            return Date.now();
          },
          formatter: function(options) {
            // Return string will be passed to logger.
            return header + ': '+ options.level.toUpperCase() +': '+ (options.message ? options.message : '') +
              (options.meta && Object.keys(options.meta).length ? ': '+ JSON.stringify(options.meta) : '' );
          }
        })
      ]
    });
};
