node things.js config.json
