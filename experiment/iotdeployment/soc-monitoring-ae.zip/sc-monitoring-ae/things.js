// Included Libraries
const IPC = require('ipc-event-emitter').IPCEventEmitter;
const fs = require('fs');
const async = require('async');
const cse = require('./cse');
const spawn = require('child_process').spawn;
const readline = require('readline');

// Startup: Initalize sensor script
config = JSON.parse(fs.readFileSync(process.argv[2]));
configFileName = process.argv[2];
global.config = config;

const winston = require('./logger').createLogger(configFileName);
global.winston = winston;

// Global Variable
var things = {}

const sendDataOnInterval = function(thingID) {
    choosenData = things[thingID].buffer[0];
    if(choosenData != undefined) {
        //winston.info('Sending thing data to CSE', {id: thingID, data: choosenData});
        cse.request({
            "originator": config.cse.originator,
            "address": config.cse.address,
            "base": config.cse.base,
            "point": "/" + thingID,
            "method": "POST",
            "ty": 4,
            "body": {
                "m2m:cin": {
                    "cnf": "text",
                    "con": choosenData
                }
            }
        }, function(err) {
        });
        things[thingID].buffer = [];
    }
}
const startTas = function(thingID, callback) {
    winston.info("Starting a thing", {id: thingID});
    things[thingID].process = spawn(things[thingID].script);
    things[thingID].process.stdin.write(things[thingID].rate.toString() + "\n");    // Send default rate
    things[thingID].buffer = []

    dataOutput = readline.createInterface({
        input: things[thingID].process.stdout
    });

    dataOutput.on('line', function(data) {
        things[thingID].buffer.push(data);
    });


    if(things[thingID].rate > 0) {
        things[thingID].scheduler = setInterval(function() {
            sendDataOnInterval(thingID);
        }, things[thingID].rate * 1000);
    }

    callback(null);
};


const controlThingRate = function(thingID, rate, callback) {
//console.log(thingID);
    winston.info('Controlling thing rate', {id: thingID, rate: rate});
    things[thingID].rate = rate;

    things[thingID].process.stdin.write(things[thingID].rate.toString() + "\n");
    things[thingID].buffer = []


    clearInterval(things[thingID].scheduler);

    if(things[thingID].rate > 0) {
        things[thingID].scheduler = setInterval(function() {
            sendDataOnInterval(thingID);
        }, things[thingID].rate * 1000);
    }
};

async.eachOfSeries(config.aes, function(val, aeName, callback) {
    winston.info('Initializing thing for AE', {aeName: aeName});
    async.series([
        function(callback) {
            // Create (or edit) AEs
            cse.serialRequests([{
                "originator": config.cse.originator,
                "address": config.cse.address,
                "base": config.cse.base,
                "point": "/",
                "method": "POST",
                "convertToPut": true,
                "ty": 2,
                "npAttr": ["api"],
                "body": {
                    "m2m:ae": {
                        "rn": aeName,
                        "api":config.aes[aeName].app_id,
                        "rr": false,
                    }
                }
            // Create metadata for this AE
            // If the CSE supports semanticDescriptor, use that way
            // If not, save it into a "metadata" container
            }, {
                "originator": config.cse.originator,
                "address": config.cse.address,
                "base": config.cse.base,
                "convertToPut": true,
                "point": "/" + aeName,
                "method": "POST",
                "ty": 3,
                "body": {
                    "m2m:cnt": {
                        "rn": global.config.cse.mobius? "metadata": "_metadata",
                        "mni": 50
                    }
                }
            }, {
                "originator": config.cse.originator,
                "address": config.cse.address,
                "base": config.cse.base,
                "convertToPut": true,
                "point": "/" + aeName + (global.config.cse.mobius? "/metadata": "/_metadata"),
                "method": "POST",
                "ty": 4,
                "body": {
                    "m2m:cin": {
                        "cnf": "application/json",
                        "con": JSON.stringify(config.aes[aeName].metadata)
                    }
                }
            }], function(err, results) {
                callback(err);
            });
        },


        // Intialize container
        function(callback) {
            async.eachOfSeries(config.aes[aeName].containers, function(val, thingName, callback) {
                thingData = config.aes[aeName].containers[thingName];
                thingID = aeName + "/" + thingName;
                things[thingID] = {
                    script: thingData.tas_script,
                    type: thingData.type,
                    rate: thingData.default_rate,
                    scheduler: null,
                    process: null,
                    buffer: []
                };

                async.series([
                    // Container Initialization
                    function(callback) {
                        cse.serialRequests([{
                            "originator": config.cse.originator,
                            "address": config.cse.address,
                            "base": config.cse.base,
                            "convertToPut": true,
                            "point": "/" + aeName,
                            "method": "POST",
                            "ty": 3,
                            "body": {
                                "m2m:cnt": {
                                    "rn": thingName,
                                    "mni": 50
                                }
                            }

                        },{
                            "originator": config.cse.originator,
                            "address": config.cse.address,
                            "base": config.cse.base,
                            "convertToPut": true,
                            "point": "/" + aeName,
                            "method": "POST",
                            "ty": 3,
                            "body": {
                                "m2m:cnt": {
                                    "rn": (global.config.cse.mobius? "XX": "_") + thingName,
                                    "mni": 50
                                }
                            }

                        },{
                            "originator": config.cse.originator,
                            "address": config.cse.address,
                            "base": config.cse.base,
                            "convertToPut": true,
                            "point": "/" + aeName + (global.config.cse.mobius? "/XX": "/_") + thingName,
                            "method": "POST",
                            "ty": 4,
                            "body": {
                                "m2m:cin": {
                                    "cnf": "application/json",
                                    "con": JSON.stringify(config.aes[aeName].containers[thingName].metadata)
                                }
                            }
                        },{
                            "originator": config.cse.originator,
                            "address": config.cse.address,
                            "base": config.cse.base,
                            "point": "/" + aeName + "/" + thingName,
                            "method": "POST",
                            "convertToPut": true,
                            "ty": 23,
                            "body": {
                                "m2m:sub": {
                                    "rn": "qe-sub",
                                    "nu": ["http://127.0.0.1:1111"],
                                    "nct":2

                                }
                           }
                        }], function(err) {
                            callback();
                        });
                    },

                    // Start TAS and its event handling
                    function(callback) {
                        startTas(thingID, callback);
                    }
                ], function(err) {
                    callback(err);
                });
            }, function(err) {
                callback(err);
            });
        }
    ], function(err) {
            callback(err);
    });
}, function(err) {

});


// Startup: Create instance of AE for this thing-manager
cse.request({
    "originator": config.cse.originator,
    "address": config.cse.address,
    "base": config.cse.base,
    "point": "/",
    "method": "POST",
    "convertToPut": true,
    "ty": 2,
    "npAttr": ["api"],
    "body": {
        "m2m:ae": {
            "rn": "thing-manager",
            "api": config.thing_manager.api,
            "rr": true,
            "poa": ["http://" + config.thing_manager.host + ":" + config.thing_manager.port]
        }
    }
}, function(err, results) {
});

// Startup: Determine from where things can be controlled
if(process.send == undefined) {
    //console.log("Not a child process");

    // Use socket.io for command retrieved
    // So they can be controlled from a remote QE
    winston.info('Socket IO server started', {port: config.thing_manager.port});
    var io = require('socket.io')(config.thing_manager.port);
    io.on('connection', function(socket) {
        winston.info('A client connect to thing manager');
        socket.on('controlThingRate', controlThingRate)
    });


} else {
    //console.log("A child process")

    // Use EventEmitter based IPC
    var controllerEvent = new IPC(process);

    controllerEvent.on('controlThingRate', controlThingRate);

}
